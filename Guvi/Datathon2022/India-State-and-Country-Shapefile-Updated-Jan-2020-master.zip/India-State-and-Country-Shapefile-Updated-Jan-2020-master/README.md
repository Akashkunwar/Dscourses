# India-State-and-Country-Shape-File-Updated-Jan-2020

This repository contains two shape file:

* The India Boundary Shape File represents the boundary of the Republic of India as per survey of India records. 

* The State Boundary shape File represents the boundary of 28 the Indian states and 9 Union Territories (Including newly developed Jammu and Ladakh, Dadar and Nagar Haveli and Daman and Diu).

On 31 October 2019, Jammu and Kashmir state was bifurcated into 2 new Union Territories- Union Territory of Jammu and Kashmir and Union Territory of Ladakh. On 26 January 2020, Union Territory of Daman and Diu and Union Territory of Dadra and Nagar Haveli were merged into one Union Territory - Union Territory of Dadra and Nagar Haveli and Daman and Diu. All the updates are made in the current shapfile.

Please feel free to use it for your personal purposes.

By- Anuj Tiwari
Email: anujtiwari.spatial@gmail.com
